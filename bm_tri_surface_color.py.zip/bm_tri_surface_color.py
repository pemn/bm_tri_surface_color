#!python
# Copyright 2019 Vale
# github.com/pemn/bm_tri_surface_color
# create a georeferenced image with block color along a surface
# input_tri: surface
# input_scd: legend file containing a block_color legend with same name as variable
# input_bmf: block model file
# input_var: block model variable with legend color
# output: vulcan ireg with georeferencing and a png with same name with the texture
# v1.0 05/2019 paulo.ernesto
'''
usage: $0 input_tri*00t input_scd*scd input_bmf*bmf input_var:input_bmf output*ireg
'''
import sys
import pandas as pd
import numpy as np
import math
import skimage.io
#!python
'''
Copyright 2017 Vale

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

*** You can contribute to the main repository at: ***

https://github.com/pemn/usage-gui
---------------------------------

'''

### UTIL { ###
update_repository = "\\\\macfsclus01\\Geodados\\Geologia\\_Arq_Scripts\\python\\"

import sys, os, os.path, time
# fix for wrong path of pythoncomXX.dll in vulcan 10.1.5
if 'VULCAN_EXE' in os.environ:
  os.environ['PATH'] += ';' + os.environ['VULCAN_EXE'] + "/Lib/site-packages/pywin32_system32"

def usage_gui(usage = None):
  '''
  this function handles most of the details required when using a exe interface
  '''
  # we already have argument, just proceed with execution
  if(len(sys.argv) > 1):
    # traps help switches: /? -? /h -h /help -help
    if(usage is not None and re.match(r'[\-/](?:\?|h|help)$', sys.argv[1])):
      print(usage)
    elif 'main' in globals():
      main(*sys.argv[1:])
    else:
      print("main() not found")
  else:
    AppTk(usage).mainloop()


def pd_get_dataframe(input_path, condition = "", table_name = None, vl = None, keep_null = False):
  '''
  convenience function to return a dataframe base on the input file extension
  bmf: vulcan block model
  isis: vulcan database
  csv: ascii table
  xls: excel table
  '''

  if table_name is None:
    input_path, table_name = table_name_selector(input_path)

  import pandas as pd
  df = pd.DataFrame()
  if input_path.lower().endswith('csv'):
    df = pd.read_csv(input_path, encoding="latin1")
    if len(condition) > 0:
      df.query(condition, True)
  elif input_path.lower().endswith('xlsx'):
    if pd.__version__ < '0.20':
      import openpyxl
      wb = openpyxl.load_workbook(input_path)
      data = wb.active.values
      if table_name and table_name in wb:
        data = wb[table_name].values
      cols = next(data)
      df = pd.DataFrame(data, columns=cols)
    else:
      df = pd.read_excel(input_path, table_name)
      if not isinstance(df, pd.DataFrame):
        _, df = df.popitem(False)

    if len(condition) > 0:
      df.query(condition, True)
  elif input_path.lower().endswith('bmf'):
    import vulcan
    bm = vulcan.block_model(input_path)

    # get a DataFrame with block model data
    if vl is not None:
      vl = filter(bm.is_field, vl)
    df = bm.get_pandas(vl, bm_sanitize_condition(condition))
  elif input_path.lower().endswith('isis'):
    if os.path.exists(input_path + '_lock'):
      raise Exception('Input database locked')
    import vulcan
    db = vulcan.isisdb(input_path)
    # by default, use last table which is the desired one in most cases
    if table_name is None or table_name not in db.table_list():
      table_name = db.table_list()[-1]

    field_list = list(db.field_list(table_name))
    fdata = []
    db.rewind()
    while not db.eof():
      if table_name == db.get_table_name():
        fdata.append([db.get_key()] + [db[field] for field in field_list])
      db.next()
    key = db.synonym('GEO','HOLEID')
    if not key:
      key = 'KEY'
    df = pd.DataFrame(fdata, None, [key] + field_list)
    # df.to_csv('df.csv')
    if len(condition) > 0:
      df.query(condition, True)
  elif input_path.lower().endswith('dm'):
    import win32com.client
    dm = win32com.client.Dispatch('DmFile.DmTable')
    dm.Open(input_path, 0)
    fdata = []
    n = dm.Schema.FieldCount + 1
    for i in range(dm.GetRowCount()):
      fdata.append([dm.GetColumn(j) for j in range(1, n)])
      dm.GetNextRow()
    
    df = pd.DataFrame(fdata, None, [dm.Schema.GetFieldName(j) for j in range(1, n)])
    if len(condition) > 0:
      df.query(condition, True)

  # replace -99 with NaN, meaning they will not be included in the stats
  if not int(keep_null):
    df.mask(df == -99, inplace=True)

  return(df)

def pd_save_dataframe(df, save_path):
  import pandas as pd
  # screen
  if(df.size > 0):
    # Excel sheet
    if save_path.lower().endswith('.xlsx'):
      df.to_excel(save_path)
    elif len(save_path) > 0:
      df.reset_index(inplace=True)
      if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.droplevel(1)
      df.to_csv(save_path, index=False)
    else:
      print(df.to_string())
  else:
    print(save_path,"empty")

def pd_synonyms(df, synonyms):
  '''
  from a list of synonyms, find the best candidate amongst the dataframe columns
  '''
  if len(synonyms) == 0:
    return(df.columns[0])
  # first try a direct match
  for v in synonyms:
    if v in df:
      return(v)
  # second try a case insensitive match
  for v in synonyms:
    m = df.columns.str.match(v, False)
    if m.any():
      return(df.columns[m.argmax()])
  # fail safe to the first column
  return(df.columns[0])

def table_name_selector(input_path, table_name = None):
  if table_name is None:
    m = re.match(r'^(.+)!(\w+)$', input_path)
    if m:
      input_path = m.group(1)
      table_name = m.group(2)

  return(input_path, table_name)

def bm_sanitize_condition(condition):
  if condition is None:
    condition = ""

  if len(condition) > 0:

    # convert a raw condition into a actual block select string
    if re.match(r'\s*\-', condition):
      # condition is already a select syntax
      pass
    elif re.search(r'\.00t$', condition, re.IGNORECASE):
      # bounding solid
      condition = '-X -t "%s"' % (condition)
    else:
      condition = '-C "%s"' % (condition.replace('"', "'"))

  return condition

# convert field names in the TABLE:FIELD to just FIELD
def table_field(args, table=False):
  if isinstance(args, list):
    args = [table_field(arg, table) for arg in args]
  elif args.find(':') != -1:
    if table:
      args = args[0:args.find(':')]
    else:
      args = args[args.find(':')+1:]
  return(args)

# wait and unlock block model
def bmf_wait_lock(path, unlock = False, tries = None):
    blk_lock = os.path.splitext(path)[0] + ".blk_lock"

    print("waiting lock", blk_lock)
    while os.path.isfile(blk_lock):
        if unlock and not tries:
          os.remove(blk_lock)
          print("removed lock", blk_lock)
          break
        
        if tries == 0:
          break
        if tries is not None:
          tries -= 1
          print("waiting lock", blk_lock, tries, "seconds")
          
        
        time.sleep(1)
        

### } UTIL ###

## GUI { ###
import re
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.messagebox as messagebox
import tkinter.filedialog as filedialog
import pickle
import threading

class ClientScript(list):
  '''Handles the script with the same name as this interface file'''
  # magic signature that a script file must have for defining its gui
  _magic = r"usage:\s*\S+\s*([^\"\'\\]+)"
  _usage = None
  _type = None
  _file = None
  _base = None
  @classmethod
  def init(cls, client):
    cls._file = client
    cls._base = os.path.splitext(cls._file)[0]
    # HARDCODED list of supporte file types
    # to add a new file type, just add it to the list
    for ext in ['csh','lava','pl','bat','vbs','js']:
      if os.path.exists(cls._base + '.' + ext):
        cls._file = cls._base + '.' + ext
        cls._type = ext.lower()
        break

  @classmethod
  def exe(cls):
    if cls._type == "csh":
      return ["csh","-f"]
    if cls._type == "bat":
      return ["cmd", "/c"]
    if cls._type == "vbs" or cls._type == "js":
      return ["cscript", "/nologo"]
    if cls._type == "lava" or cls._type == "pl":
      return ["perl"]
    if cls._type is None:
      return ["python"]
    return []

  @classmethod
  def run(cls, script):
    print("# %s %s started" % (time.strftime('%H:%M:%S'), cls.file()))
    p = None
    if cls._type is None:
      import multiprocessing
      p = multiprocessing.Process(None, main, None, script.get())
      p.start()
      p.join()
      p = p.exitcode
    else:
      import subprocess
      # create a new process and passes the arguments on the command line
      p = subprocess.Popen(cls.exe() + [cls._file] + script.getArgs())
      p.wait()
      p = p.returncode

    if not p:
      print("# %s %s finished" % (time.strftime('%H:%M:%S'), cls.file()))
    return(p)

  @classmethod
  def type(cls):
    return cls._type
  
  @classmethod
  def base(cls):
    return cls._base
  
  @classmethod
  def file(cls, ext = None):
    if ext is not None:
      return cls._base + '.' + ext
    return os.path.basename(cls._file)
  
  @classmethod
  def args(cls, usage = None):
    r = []
    if usage is None and cls._type is not None:
      usage = cls.parse()

    if usage:
      m = re.search(cls._magic, usage, re.IGNORECASE)
      if(m):
        cls._usage = m.group(1)
    
    if cls._usage is None or len(cls._usage) == 0:
      r = ['arguments']
    else:
      r = cls._usage.split()
    return(r)

  @classmethod
  def fields(cls, usage = None):
    return [re.match(r"^\w+", _).group(0) for _ in cls.args(usage)]

  @classmethod
  def parse(cls):
    if os.path.exists(cls._file):
      with open(cls._file, 'r') as file:
        for line in file:
          if re.search(cls._magic, line, re.IGNORECASE):
            return(line)
    return None

  @classmethod
  def header(cls):
    r = ""
    if os.path.exists(cls._file):
      with open(cls._file, 'r') as file:
        for line in file:
          if(line.startswith('#!')):
            continue
          m = re.match(r'#\s*(.+)', line)
          if m:
            r += m.group(1) + "\n"
          else:
            break
    return r

class Settings(str):
  '''provide persistence for control values using pickled ini files'''
  _ext = '.ini'
  def __new__(cls, value=''):
    if len(value) == 0:
      value = os.path.splitext(os.path.realpath(sys.argv[0]))[0]
    if not value.endswith(cls._ext):
      value += cls._ext

    return super().__new__(cls, value)

  def save(self, obj):
    pickle.dump(obj, open(self,'wb'), -1)
    
  def load(self):
    if os.path.exists(self):
      return(pickle.load(open(self, 'rb')))
    return({})

# subclass of list with a string representation compatible to perl argument input
# which expects a comma separated list with semicolumns between rows
# this is to mantain compatibility with older versions of the usage gui
class commalist(list):
  _rowfs = ";"
  _colfs = ","
  def parse(self, arg):
    "fill this instance with data from a string"
    if isinstance(arg, str):
      for row in arg.split(self._rowfs):
        self.append(row.split(self._colfs))
    else:
      self = commalist(arg)

    return self

  def __str__(self):
    r = ""
    # custom join
    for i in self:
      if(isinstance(i, list)):
        i = self._colfs.join(i)
      if len(r) > 0:
        r += self._rowfs
      r += i
    return(r)
  def __hash__(self):
    return(len(self))

  # sometimes we have one element, but that element is ""
  # unless we override, this will evaluate as True
  def __bool__(self):
    return len(str(self)) > 0
  # compatibility if the user try to treat us as a real string
  def split(self, *args):
    return [",".join(_) for _ in self]

def dgd_list_layers(file_path):
  import vulcan
  r = []
  # return the list of layers stored in a dgd
  db = vulcan.isisdb(file_path)
  for record in db.keys:
    if db.get_key().find('$') == -1:
      r.append(db.get_key())
  return r

def bmf_field_list(file_path):
  import vulcan
  bm = vulcan.block_model(file_path)
  r = bm.field_list()
  bm.close()
  return r

def isisdb_field_list(file_path):
  import vulcan
  db = vulcan.isisdb(file_path)
  r = db.field_list(db.table_list()[-1])
  db.close()
  return r

def dm_field_list(file_path):
  import win32com.client
  dm = win32com.client.Dispatch('DmFile.DmTable')
  dm.Open(file_path, 0)
  r = [dm.Schema.GetFieldName(j) for j in range(1, dm.Schema.FieldCount + 1)]
  return r

class smartfilelist(object):
  '''
  detects file type and return a list of relevant options
  searches are cached, so subsequent searcher for the same file path are instant
  '''
  # global value cache, using path as key
  _cache = {}
  @staticmethod
  def get(input_path):
    # special case for multiple files. use first
    if isinstance(input_path, commalist):
      if len(input_path):
        input_path = input_path[0][0]
      else:
        input_path = ""

    # if this file is already cached, skip to the end
    if(input_path in smartfilelist._cache):
      # do nothing
      pass
    elif(os.path.exists(input_path)):
      if(input_path.lower().endswith(".dgd.isis")):
        # list layers of vulcan dgd files
        smartfilelist._cache[input_path] = dgd_list_layers(input_path)
      elif(input_path.lower().endswith(".bmf")):
        # vulcan block model
        smartfilelist._cache[input_path] = bmf_field_list(input_path)
      elif(input_path.lower().endswith(".isis")):
        # vulcan isis database
        smartfilelist._cache[input_path] = isisdb_field_list(input_path)
      elif(re.search("csv|xls.?$", input_path, re.IGNORECASE)):
        # list columns of files handled by pd_get_dataframe
        smartfilelist._cache[input_path] = list(pd_get_dataframe(input_path).columns)
      elif(input_path.lower().endswith(".dm")):
        smartfilelist._cache[input_path] = dm_field_list
    else: # default to a empty list
      smartfilelist._cache[input_path] = []

    return(smartfilelist._cache[input_path])

class UsageToken(str):
  '''handles the token format used to creating controls'''
  _name = None
  _type = None
  _data = None
  def __init__(self, arg):
    super().__init__()
    m = re.match(r"(\w*)(\*|@|#|=|:)(.*)", arg)
    if (m):
      self._name = m.group(1)
      self._type = m.group(2)
      self._data = m.group(3)
    else:
      self._name = arg
  @property
  def name(self):
    return self._name
  @property
  def type(self):
    return self._type
  @property
  def data(self):
    return self._data


class ScriptFrame(ttk.Frame):
  '''frame that holds the script argument controls'''
  _tokens = None
  def __init__(self, master, usage = None):
    ttk.Frame.__init__(self, master)

    self._tokens = [UsageToken(_) for _ in ClientScript.args(usage)]
    # for each token, create a child control of the apropriated type
    for token in self._tokens:
      c = None
      if token.type == '@':
        c = CheckBox(self, token.name, int(token.data) if token.data else 0)
      elif token.type == '*':
        c = FileEntry(self, token.name, token.data)
      elif token.type == '=':
        c = LabelCombo(self, token.name, token.data)
      elif token.type == ':':
        c = ComboPicker(self, token.name, token.data)
      elif token.type == '#':
        c = tkTable(self, token.name, token.data.split('#'))
      elif token.name:
        c = LabelEntry(self, token.name)
      else:
        continue
      c.pack(anchor="w", padx=20, pady=10, fill=tk.BOTH)
      
  def copy(self):
    "Assemble the current parameters and copy the full command line to the clipboard"
    cmd = " ".join(ClientScript.exe() + [ClientScript.file()] + self.getArgs(True))
    print(cmd)
    self.master.clipboard_clear()
    self.master.clipboard_append(cmd)
    # workaround due to tkinter clearing clipboard on exit
    messagebox.showinfo(message='Command line copied to clipboard.\nWill be cleared after interface closes.')
  
  @property
  def tokens(self):
    return self._tokens

  # get panel parameters as a list of strings
  def get(self, labels=False):
    if labels:
      return dict([[k, v.get()] for k,v in self.children.items()])
    return [self.children[t.name].get() for t in self.tokens]
  
  # get panel parameters as a flat string
  def getArgs(self, quote_blank = False):
    args = []
    for t in self.tokens:
      arg = str(self.children[t.name].get())
      if (quote_blank and (len(arg) == 0 or ('"' not in arg and (' ' in arg or ';' in arg or "\\" in arg)))):
        arg = '"' + arg + '"'
      args.append(arg)

    return(args)
  
  def set(self, values):
    if isinstance(values, dict):
      for k,v in self.children.items():
        if k in values:
          v.set(values[k])
    else:
      for i in range(len(self.tokens)):
        self.children[self.tokens[i].name].set(values[i])

class LabelEntry(ttk.Frame):
  ''' should behave the same as Tix LabelEntry but with some customizations '''
  _label = None
  _control = None
  def __init__(self, master, label):
    # create a container frame for the combo and label
    ttk.Frame.__init__(self, master, name=label)
    
    if isinstance(master, tkTable):
      self._control = ttk.Entry(self)
    else:
      #self._control = ttk.Entry(self, width=60)
      self._control = ttk.Entry(self)
      self._label = ttk.Label(self, text=label, width=-20)
      self._label.pack(side=tk.LEFT)

    self._control.pack(expand=True, fill=tk.BOTH, side=tk.RIGHT)
    
  def get(self):
    return(self._control.get())
   
  def set(self, value):
    if(value == None or len(value) == 0):
      return
    self._control.delete(0, tk.END)
    self._control.insert(0, value)

  def configure(self, **kw):
    if self._label is not None:
      self._label.configure(**kw)
    self._control.configure(**kw)
  
class CheckBox(ttk.Checkbutton):
  '''superset of checkbutton with a builtin variable'''
  def __init__(self, master, label, reach=0):
    self._variable = tk.BooleanVar()
    self._reach = reach
    ttk.Checkbutton.__init__(self, master, name=label, text=label, variable=self._variable)
    self.bind("<ButtonPress>", self.onButtonPress)
    self.bind("<Configure>", self.onButtonPress)

  def onButtonPress(self, event=None):
    if self._reach > 0:
      value = self.get()
      # invert the selection when caller is the onclick
      # because the current value is the oposite of the future value
      if int(event.type) == 4:
        value = not value
      bubble = 0
      for v in sorted(self.master.children.values(), key=tk.Misc.winfo_y):
        if(v is self):
          bubble = self._reach
        elif(bubble > 0):
          bubble -= 1
          v.configure(state = "enabled" if value else "disabled")

  def get(self):
    return(int(self._variable.get()))
    
  def set(self, value):
    #self.onButtonPress()
    return(self._variable.set(value))

class LabelCombo(ttk.Frame):
  _label = None
  _control = None
  def __init__(self, master, label, source=None):
    ttk.Frame.__init__(self, master, name=label)
    self._source = source
    if isinstance(master, tkTable):
      self._control = ttk.Combobox(self)
    else:
      self._control = ttk.Combobox(self, width=-60)
      self._label = ttk.Label(self, text=label, width=-20)
      self._label.pack(side=tk.LEFT)

    self._control.pack(expand=True, fill=tk.BOTH, side=tk.RIGHT)
    if source is not None:
      self.setValues(source.split(","))

  def get(self):
    return(self._control.get())
  
  def set(self, value):
    self._control.set(value)
  
  def setValues(self, values):
    self._control['values'] = values
    # MAGIC: if only one value in the list, use it as default
    if (len(values) == 1):
      self.set(values[0])
    # MAGIC: if any of the values is the same name as the control, select it
    for _ in values:
      if _.lower() == self.winfo_name():
        self.set(_)

  def configure(self, **kw):
    if self._label is not None:
      self._label.configure(**kw)
    self._control.configure(**kw)

class ComboPicker(LabelCombo):
  def __init__(self, master, label, source):
    LabelCombo.__init__(self, master, label)
    self._source = source
    self._control.bind("<ButtonPress>", self.onButtonPress)
    
  def onButtonPress(self, *args):
    # temporarily set the cursor to a hourglass
    self._control['cursor'] = 'watch'
    source_widget = None
    if (isinstance(self.master, tkTable)):
      if (self._source in self.master.master.children):
        source_widget = self.master.master.nametowidget(self._source)
      else:
        _,_,row = self.winfo_name().rpartition("_")
        if self._source + "_" + row in self.master.children:
          source_widget = self.master.nametowidget(self._source + "_" + row)
    elif (self._source in self.master.children):
      source_widget = self.master.nametowidget(self._source)

    if source_widget:
      self.setValues(smartfilelist.get(source_widget.get()))
    else:
      self.setValues([self._source])

    # reset the cursor back to default
    self._control['cursor'] = ''

class FileEntry(ttk.Frame):
  '''custom Entry, with label and a Browse button'''
  _label = None
  _button = None
  _control = None
  def __init__(self, master, label, wildcard=None):
    ttk.Frame.__init__(self, master, name=label)
    self._button = ttk.Button(self, text="⛘", command=self.onBrowse)
    self._button.pack(side=tk.RIGHT)
    if isinstance(master, tkTable):
      self._control = ttk.Combobox(self)
    else:
      #self._control = ttk.Combobox(self, width=60)
      self._control = ttk.Combobox(self, width=-60)
      self._label = ttk.Label(self, text=label, width=-20)
      self._label.pack(side=tk.LEFT)
    self._control.pack(expand=True, fill=tk.BOTH, side=tk.RIGHT)
    self._control.bind("<ButtonPress>", self.onButtonPress)
    self._wildcard_list = wildcard.split(',')
    self._wildcard_full = ((wildcard, ['*.' + _ for _ in self._wildcard_list]), ("*", "*"))
  
  # activate the browse button, which shows a native fileopen dialog and sets the Entry control
  def onBrowse(self):
    if self._label is not None and self._label['text'].startswith("output"):
      self.set(filedialog.asksaveasfilename(filetypes=self._wildcard_full))
    else:
      flist = filedialog.askopenfilenames(filetypes=self._wildcard_full)
      if(isinstance(flist, tuple)):
        slist = []
        for n in flist:
          if os.path.commonpath([n, os.getcwd()]).lower() == os.getcwd().lower():
            slist.append(os.path.relpath(n))
          else:
            slist.append(n)
        if isinstance(self.master, tkTable) and len(slist) > 1:
          self.master.set(slist)
        else:
          self.set(",".join(slist))

  def onButtonPress(self, *args):
    # temporarily set the cursor to a hourglass
    if (len(self._control['values'])):
      return

    self._control['cursor'] = 'watch'
    
    wildcard_regex = '\.(?:' + '|'.join(self._wildcard_list) + ')$'
    self._control['values'] = [_ for _ in os.listdir('.') if re.search(wildcard_regex, _)]

    # reset the cursor back to default
    self._control['cursor'] = ''

  def get(self):
    return(self._control.get())
  
  def set(self, value):
    if(value == None or len(value) == 0):
      return
    self._control.delete(0, tk.END)
    self._control.insert(0, value)

  def configure(self, **kw):
    if self._label is not None:
      self._label.configure(**kw)
    self._button.configure(**kw)
    self._control.configure(**kw)

# create a table of entry/combobox widgets
class tkTable(ttk.Labelframe):
  def __init__(self, master, label, columns):
    ttk.Labelframe.__init__(self, master, name=label, text=label)

    self._label = label
    if len(self._label) == 0:
      self._label = str(self.winfo_id())
    self._columns = [UsageToken(_) for _ in columns]
    self._cells = []
    ttk.Button(self, text="➕", width=3, command=self.addRow).grid(row=99, column=0)
    for i in range(len(self._columns)):
      self.columnconfigure(i+1, weight=1)
      ttk.Label(self, text=self._columns[i].name).grid(row=0, column=i+1)

    self.addRow()
    # ttk.Style().configure('style.TFrame', background='green')
    # self['style'] = 'style.TFrame'
    
  # return the table data as a serialized commalist
  def get(self, row=None, col=None):
    value = ""
    # retrieve all values as a 2d list
    if(row==None and col==None):
      value = commalist()
      for i in range(len(self._cells)):
        value.append([self.get(i, j) for j in range(len(self._columns))])
  
    elif(row < len(self._cells) and col < len(self._columns)):
      value = self._cells[row][col+1].get()
    return(value)

  # set the widget values, expanding the table rows as needed
  # input data must be a string containing a serialized commalist
  def set(self, data, row=None, col=0):
    if row is None:
      data = commalist().parse(data)
      for i in range(len(data)):
        if(isinstance(data[i], list)):
          for j in range(len(data[i])):
            self.set(data[i][j], i, j)
        else:
          self.set(data[i], i)
    else:
      # expand internal array to fit the data
      for i in range(len(self._cells), row+1):
        self.addRow()
      self._cells[row][col+1].set(data)

  def addRow(self):
    row = len(self._cells)
    self._cells.append([])
    for col in range(len(self._columns)+1):
      child = None
      if col == 0:
        child = ttk.Button(self, text="✖", width=3, command=lambda: self.delRow(row))
      else:
        token = self._columns[col-1]
        if(token.type == '@'):
          child = CheckBox(self, "%s_%s" % (token.name,row))
        elif(token.type == '*'):
          child = FileEntry(self, "%s_%s" % (token.name,row), token.data)
        elif(token.type == '='):
          child = LabelCombo(self, "%s_%s" % (token.name,row), token.data)
        elif(token.type == ':'):
          child = ComboPicker(self, "%s_%s" % (token.name,row), token.data)
        else:
          child = LabelEntry(self, "%s_%s" % (token.name,row))
      child.grid(row=row+1, column=col, sticky="we")
      self._cells[row].append(child)
  
  def delRow(self, index=0):
    buffer = self.get()
    del buffer[index]
    self.clear()
    self.set(buffer)
  
  def clear(self):
    for i in range(len(self._cells)-1,-1,-1):
      for j in range(len(self._cells[i])-1,-1,-1):
        self._cells[i][j].destroy()
    del self._cells[:]

  def configure(self, **kw):
    if "state" in kw:
      for v in self.children.values():
        v.configure(**kw)
    else:
      super().configure(**kw)

# main frame
class AppTk(tk.Tk):
  '''TK-Based Data driven GUI application'''
  _iconfile_name = None
  def __init__(self, usage, client=sys.argv[0]):
    ClientScript.init(client)
    root = tk.Tk.__init__(self)
    self.title(ClientScript._base)
    
    self._iconfile_name = createIcon(os.environ['USERDOMAIN'])
    self.iconbitmap(default=self._iconfile_name)

    self.columnconfigure(0, weight=1)

    self.canvas = tk.Canvas(root, width=self.winfo_screenwidth() * 0.35)
    self.script = ScriptFrame(self.canvas, usage)
    self.vsb = ttk.Scrollbar(root, orient="vertical", command=self.canvas.yview)
    self.canvas.configure(yscrollcommand=self.vsb.set)

    self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    self.canvas_frame = self.canvas.create_window((0,0), window=self.script, anchor="nw")

    self.vsb.pack(side=tk.LEFT, fill=tk.Y)
    self.script.bind("<Configure>", self.onFrameConfigure)
    self.canvas.bind('<Configure>', self.onCanvasConfigure)

    ttk.Label(self, text=ClientScript.header()).pack(side=tk.BOTTOM)
    
    # if we dont store the image in a variable, it will be garbage colected before being displayed
    drawLogo(tk.Canvas(self), os.environ['USERDOMAIN']).pack(side=tk.TOP, anchor="ne")
    self.button = ttk.Button(self, text="Run", command=self.runScript)
    self.button.pack(side=tk.LEFT)
    
    self.progress = ttk.Progressbar(self, mode="determinate")
    self.progress.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=10)

    self.createMenu()
    self.script.set(Settings().load())

  def onCanvasConfigure(self, event):
    self.canvas.itemconfig(self.canvas_frame, width = event.width - 4)

  def onFrameConfigure(self, event):
    '''Reset the scroll region to encompass the inner frame'''
    self.canvas.configure(scrollregion=self.canvas.bbox("all"))
    self.canvas['height'] = min(self.winfo_screenheight() * 0.8, self.script.winfo_reqheight())

  def createMenu(self):
    '''create a hardcoded menu for our app'''
    # disable a legacy option to detach menus
    self.option_add('*tearOff', False)
    menubar = tk.Menu(self)
    menu_file = tk.Menu(menubar)
    menu_edit = tk.Menu(menubar)
    menu_help = tk.Menu(menubar)
    menubar.add_cascade(menu=menu_file, label='File')
    menubar.add_cascade(menu=menu_help, label='Help')
    menu_file.add_command(label='Copy Command Line', command=self.script.copy)
    menu_file.add_command(label='Open Settings', command=self.openSettings)
    menu_file.add_command(label='Save Settings', command=self.saveSettings)
    menu_file.add_command(label='Exit', command=self.destroy)
    menu_help.add_command(label='Help', command=self.showHelp)
    menu_help.add_command(label='Check for Updates', command=self.checkUpdate)
    menu_help.add_command(label='About', command=self.showAbout)
    self['menu'] = menubar
      
  def runScript(self):
    # run the process in another thread as not to block the GUI message loop
    def fork():
      self.button.configure(state = "disabled")
      self.progress.configure(value = 0, mode = "indeterminate")
      self.progress.start()
      
      if ClientScript.run(self.script):
        messagebox.showwarning(message="Check console messages",title=ClientScript.type())

      self.progress.stop()
      self.progress.configure(value = 100)
      self.progress.configure(mode = "determinate")
      self.button.configure(state = "enabled")

    threading.Thread(None, fork).start()

  def showHelp(self):
    script_pdf = ClientScript.file('pdf')
    if os.path.exists(script_pdf):
      os.system(script_pdf)
    else:
      messagebox.showerror('Help', 'Documentation file not found')
    
  def checkUpdate(self):
    if not os.path.exists(update_repository):
      messagebox.showerror('Check for Update', 'Repository not found: ' + update_repository)
      return
    path_local = ClientScript.file()
    path_remote = update_repository + ClientScript.file()
    if not os.path.exists(path_remote):
      messagebox.showwarning('Check for Update','This file is not included in update the repository')
      return
    
    statinfo_local = os.stat(path_local)
    statinfo_remote = os.stat(path_remote)
    if (statinfo_local.st_mtime - statinfo_remote.st_mtime) > 60:
      messagebox.showinfo('Check for Update', 'This script is up to date')
      return

    if messagebox.askyesno('Update','A newer version of this script is available. Update?'):
      from shutil import copy
      copy(path_remote, path_local)
      messagebox.showinfo('Check for Update', 'This script was updated and need to be restarted')
      self.destroy()


  def showAbout(self):
    messagebox.showinfo('About', 'Graphic User Interface to command line scripts')

  def openSettings(self):
    result = filedialog.askopenfilename(filetypes=[("ini", "*.ini")])
    if len(result) == 0:
      return
    self.script.set(Settings(result).load())
    
  def saveSettings(self):
    result = filedialog.asksaveasfilename(filetypes=[("ini", "*.ini")])
    if len(result) == 0:
      return
    Settings(result).save(self.script.get(True))
  
  def destroy(self):
    Settings().save(self.script.get(True))
    os.remove(self._iconfile_name)
    tk.Tk.destroy(self)

### } GUI ###

### BRANDING { ###

iconhexdata = dict()

iconhexdata['VALENET'] = \
'0000010001002020000001002000a8100000160000002800000020000000' \
'400000000100200000000000000000000000000000000000000000000000' \
'0000ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00848f005b83920023ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00828e002d838f00f6838f00cd92920007ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff008b8b000b829000d7838f00ff838f00ff8490' \
'0095ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00838e00a3838f00ff838f' \
'00ff838f00ff838f00ff828e0056ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00828f0062838f' \
'00ff838f00ff838f00ff838f00ff838f00ff838f00f1808e0024ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff008591' \
'002c838f00f6838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00cf92920007ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff008b8b000b838f00d6838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff84900097ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00838f00a1838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff828e0058ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00838e0061838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00f2868d0026ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00828e002b838f00f5838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00ff838f00ff838f00ff838f00d080800008ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff008099000a838f00d6' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838e009a' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'838f00a0838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff828e005affffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00828f0060838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00f383900027ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff008692002a838f00f5838f00ff838f00ff838f00ff838f' \
'00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00d28e8e0009ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff008099000a828e00d5838f00ff838f00ff838f' \
'00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'01fe838f00ff838f00ff838e009cffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00848f009f838f00ff838f' \
'00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff629746d032a3' \
'aac016aae3de14abeaf817aae2de22a7caca5e984bd08290005cffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00848e005f838f' \
'00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff7b9110f021a8' \
'ccc713abeaff13abeaff13abeaff13abeaff13abeaff13abeaff13abeaff' \
'1da9d5c75c964e27ffffff00ffffff00ffffff00ffffff00ffffff008692' \
'002a838f00f5838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff6796' \
'3bd515aae6e213abeaff13abeaff13abeaff13abeaff13abeaff13abeaff' \
'13abeaff13abeaff13abeaff14abe9cf1ab3e60affffff00ffffff00ffff' \
'ff008099000a838f00d4838f00ff838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff848f00991ca7d53713acea8713acead913abeaff13abeaff13abeaff' \
'13abeaff13abeaff13abeaff13abeaff13abeaff13abeaff13aceba2ffff' \
'ff00ffffff00ffffff008390009e838f00ff838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00fa828e0068ffffff00ffffff00ffffff00ffffff0014aaeb33' \
'13abeabf13abeaff13abeaff13abeaff13abeaff13abeaff13abeaff13ab' \
'eaff13abeaff14aaeb66ffffff008290005e838f00ff838f00ff838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00ff838f00e88491003cffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff0013aae95112abeadd13abeaff13abeaff13ab' \
'eaff13abeaff13abeaff13abeaff13abeaf715acea31838e00a3838f00ff' \
'838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00ff838f00ff838f00cb8092001cffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff0000aaff0614ab' \
'eb7313abeaef13abeaff13abeaff13abeaff13abeaff13abeaff13aaebbb' \
'ffffff00848f005b828f00d9838f00ff838f00ff838f00ff838f00ff838f' \
'00ff838f00ff838f00ff838f00e0838e0061aaaa0003ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff000eaaf11214aaeb5a13abeb9713abebc812abe99a' \
'14abeb581caae309ffffff00ffffff00ffffff00828e003d838f0080838f' \
'00a1838f00c2838e00b3838f00848490005380800006ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffffffffffffffffffffff' \
'fffffffffffffffffffe7ffffffc3ffffff83ffffff81ffffff00fffffe0' \
'07ffffc007ffffc003ffff8001ffff0000fffe0000fffe00007ffc00003f' \
'f800001ff000001ff000000fe0000007c00040038001f8038003fe010007' \
'ff80c01fffe3f07fffffffffffffffffffffffffffffffffffff'

iconhexdata['default'] = \
'000001000100101000000100200068040000160000002800000010000000' \
'20000000010020000000000000040000120b0000120b0000000000000000' \
'0000ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffffff00ffffff0001010100000000000000004c000000ba' \
'000000750000000000000000000000000000000000000075000000ba0000' \
'004c0000000001010100ffffff00ffffff00010101000000004b0f1a0dc8' \
'64b754fd0f1b0dc5000000230000000000000000000000230f1d0dc563c4' \
'52fd0e1c0cc80000004b01010100ffffff00ffffff00010101190a1009b6' \
'58994af35eb04dff3f7035e60000007a00000000000000000000007a3e77' \
'34e665c754ff56a948f3091008b601010119ffffff00ffffff0001010163' \
'3b5d33da5ca64bff5aa649ff5ba64afc000000b600000000000000000000' \
'00b65eb54efc62bf51ff64c253ff34602cda01010163ffffff00ffffff00' \
'01010194659d57f0579d46ff579f46ff427a36ee0101017e010101000101' \
'01000101017e47863aee5fb54eff60b94fff58a04af001010194ffffff00' \
'ffffff00020202a979ba69fc60a44fff579b46ff0b1309bd010101180101' \
'010001010100010101180c150abd5bab4aff5daf4cff68b657fc020202a9' \
'ffffff00ffffff00020202a37fc16efc66aa55ff64a853ff0d150bb90101' \
'01180101010001010100010101180c140ab958a247ff59a548ff6cb45bfc' \
'020202a3ffffff00ffffff000303038579b26bec6aae59ff69ad58ff3456' \
'2cd2010101760101011701010117010101762b4d23d2569c45ff5aa149ff' \
'6aa45bec03030385ffffff00ffffff00030303544d6f45c980c46fff70b4' \
'5fff6cad5cfb395b31d10f170db40f170db4395b31d16cad5cfb70b45fff' \
'7cc06bff496a40c903030354ffffff00ffffff000303031410160f9281bc' \
'72eb82c671ff79bd68ff79bd68ff79bd68ff79bd68ff79bd68ff79bd68ff' \
'80c46fff7eb86feb10160e9203030314ffffff00ffffff00030303000404' \
'04381b25189c84bf75eb8fd37eff86ca75ff82c671ff82c671ff86ca75ff' \
'8ed27dff82bd73eb1b25189c0404043803030300ffffff00ffffff000303' \
'030004040400040404361218108a507248c084be75e794d784fa94d784fa' \
'83bd74e7507247c01218108a040404360404040003030300ffffff00ffff' \
'ff00030303000404040004040400040404120404044a0404047104040485' \
'04040485040404710404044a04040412040404000404040003030300ffff' \
'ff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00' \
'ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffffff00ffff' \
'ff00ffffff00ffff0000ffff0000e3c70000c18300008181000081810000' \
'818100008181000081810000800100008001000080010000c0030000e007' \
'0000f00f0000ffff0000'

def drawLogo(canvas, choice = None):
    '''draw a custom logo that will fit the ne corner of our app'''
    if choice == 'VALENET':
        canvas.create_polygon(875,242, 875,242, 974,112, 974,112, 863,75, 752,112, 752,112, 500,220, 386,220, 484,757, fill="#eaab13", smooth="true")
        canvas.create_polygon(10,120, 10,120, 218,45, 554,242, 708,312, 875,242, 875,242, 484,757, 484,757, fill="#008f83", smooth="true")
    else:
        canvas.create_arc(50, 50, 950, 950, outline='', fill="#3fa648", start=290, extent=320)
        canvas.create_oval(360, 360, 640, 640, outline='', fill=canvas["background"])
    canvas['height'] = 100
    canvas['width'] = 100
    canvas.scale("all", 0, 0, 0.1, 0.1)
    return canvas


def createIcon(choice = None):
    import tempfile, binascii
    # create temp icon file, will be cleaned by tk.Tk destroy
    iconfile = tempfile.NamedTemporaryFile(delete=False)
    if choice not in iconhexdata:
        choice = 'default'

    iconfile.write(binascii.a2b_hex(iconhexdata[choice]))
    return iconfile.name

### } BRANDING ###

# default main for when this script is standalone
# when this as a library, will redirect to the caller script main()
def main(*args):
  if (__name__ != '__main__'):
    from __main__ import main
    # redirect to caller script main
    main(*args)
    return
  # run standalone main code
  print(__name__)
  print(args)
  messagebox.showinfo(message='Business Logic placeholder')

# special entry point for cmd
if __name__ == '__main__' and sys.argv[0].endswith('_gui.py') and len(sys.argv) == 2:
  AppTk(None, sys.argv[1]).mainloop()

#!python
# Copyright 2019 Vale
# parse vulcan map files using a DSL engine
# v1.0 04/2018 paulo.ernesto

import sys, os.path
sys.path.insert(0, os.path.splitext(sys.argv[0])[0] + '.zip')

import lark

#%import common.WS
#%import common.CNAME
mapfile_grammar = r"""
  WS: /[ \t\f\r\n]/+
  LCASE_LETTER: "a".."z"
  UCASE_LETTER: "A".."Z"
  LETTER: UCASE_LETTER | LCASE_LETTER
  WORD: LETTER+
  DIGIT: "0".."9"
  CNAME: ("_"|LETTER) ("_"|LETTER|DIGIT)*

  ?start: file

  ?value: definition
        | tab
        | pair
        | terminal

  file: value+ "END" "$FILE"
  COMMENT: /\*.*/
  definition: "BEGIN" "$DEF" CNAME value+ "END" "$DEF" CNAME
  tab: "BEGIN" "$TAB" CNAME value+ "END" "$TAB" CNAME
  ESCAPED_STRING: "'" ("\\'"|/[^']/)* "'"
  terminal: ESCAPED_STRING | CNAME
  pair: CNAME "=" [terminal]


  %ignore WS
  %ignore COMMENT
"""

class MapfileTransformer(lark.Transformer):
  pair = lambda self, _: [_[0].value, _[1]]
  definition = lambda self, _: [_[0].value, _[1:-1]]
  tab = lambda self, _: [_[0].value, _[1:-1]]
  file = dict
  terminal = lambda self, _: str.strip(_[0],"'")

def mapfile_parse(input_path):
  parser = lark.Lark(mapfile_grammar, parser='lalr', transformer=MapfileTransformer())
  with open(input_path) as f:
    return(parser.parse(f.read()))
  return({})

class VulcanScd(object):

  def __init__(self, input_path, v_def = None, v_tab = None):
    self._parse = mapfile_parse(input_path)
    
    self._device_color = None
    if 'DEVICE_COLOUR' in self._parse:
      self._device_color = self._parse['DEVICE_COLOUR'][0][1]

    self._def = None
    self._tab = None
    if v_def is not None:
      if v_def in self._parse:
        self._def = self._parse[v_def]
      
      if v_tab is not None:
        v_tab = str(v_tab).upper()
        self._tab = dict(self._def)
        if v_tab in self._tab:
          self._tab = self._tab[v_tab]

  def __getitem__(self, key):
    if self._def is None or self._tab is None:
      return(None)
    c = None
    for i in range(len(self._tab)):
      if self._tab[i].upper() == str(key).upper():
        c = int(self._tab[i - 1])
        break
    rgb = (1,1,1)
    if c is not None and self._device_color is not None:
      for i in range(0,len(self._device_color),4):
        if int(self._device_color[i]) == c:
          rgb = [float(self._device_color[_]) / 15.0 for _ in (i+1, i+3, i+2)]
    return(rgb)
#!python
# Copyright 2019 Vale
# voxelscheme
# v1.0 05/2019 paulo.ernesto

import numpy as np
import csv


# normalized voxel cube around all xyz points of a csv file
class Voxelschema(np.ma.MaskedArray):
  def __new__(cls, size, dimensions):
    if len(size) > 3:
      size = size[0:3]
    self = super().__new__(cls, np.ndarray(dimensions), np.ones(np.prod(dimensions), np.bool_))
    self._bl = np.array(size)
    self._o0 = np.zeros(3);
    return(self)

  # return the ijk of a voxel using our fixed voxel size instead of the voxel own size
  def ijk(self, xyz):
    #(block_centre, block_length) = Voxel.block(self._data.ix[c])
    #return tuple(int((xyz[i] - self._o0[i]) // self._bl[i]) for i in range(3))
    return np.divide(np.subtract(xyz, self._o0), self._bl).astype(np.int_)

  def xyz(self, ijk):
    return np.add(np.multiply(ijk, self._bl), self._o0)

  def block_extent(self, xyzc, xyzl):
    xyzr = np.multiply(xyzl, 0.5)
    return np.subtract(xyzc, xyzr), np.add(xyzc, xyzr)

  def flag_by_block(self, xyzc, xyzl, value, mode = 'first'):
    xyz0, xyz1 = self.block_extent(xyzc, xyzl)
    return self.flag_by_extent(xyz0, xyz1, value, mode)

  # flag grid cells that are touched by a block
  # in the case of multiple blocks touching a cell
  # use the block which intersects with the greater volume
  # input: block corners
  def flag_by_extent(self, xyz0, xyz1, value, mode = 'first'):
    ijk0 = self.ijk(xyz0)
    ijk1 = self.ijk(xyz1)
    # ijkd = np.subtract(ijk1, ijk0, dtype=np.int_, casting='unsafe')
    ijkd = np.subtract(ijk1, ijk0)
    for i in range(ijk0[0], ijk0[0] + ijkd[0]):
      for j in range(ijk0[1], ijk0[1] + ijkd[1]):
        for k in range(ijk0[2], ijk0[2] + ijkd[2]):
          if self[i,j,k] is np.ma.masked:
            pass
          elif mode == 'max' and self[i,j,k] < value:
            pass
          elif mode == 'min' and self[i,j,k] > value:
            pass
          else:
            continue

          self[i,j,k] = value

    return self

  def get_k_minmax(self, i, j, mode = 'max'):
    k = 0
    ks = self[i, j, :]
    if mode == 'max':
      k = ks.argmax()
    else:
      k = ks.argmin()
    return k

  def get_2d_minmax(self, mode = 'max'):
    grid = np.ma.MaskedArray(np.ndarray(self.shape[0:2]), np.ones(np.prod(self.shape[0:2]), np.bool_))
    for i in range(self.shape[0]):
      for j in range(self.shape[1]):
        k = self.get_k_minmax(i, j, mode)
        grid[i,j] = k

    return grid

  def save_2d_grid(self, path, grid):

    with open(path, 'w', newline='') as csvfile:
      csvwriter = csv.writer(csvfile, quoting=csv.QUOTE_MINIMAL)
      csvwriter.writerow(['i', 'j','value'])
      for i in range(grid.shape[0]):
        for j in range(grid.shape[1]):
          csvwriter.writerow([i, j, grid[i,j]])

  def save_grid(self, path):
    with open(path, 'w', newline='') as csvfile:
      csvwriter = csv.writer(csvfile, quoting=csv.QUOTE_MINIMAL)
      csvwriter.writerow(['i', 'j', 'k','value'])
      for i in range(self.shape[0]):
        for j in range(self.shape[1]):
          for k in range(self.shape[2]):
            csvwriter.writerow([i, j, k, self[i,j,k]])
#!python
# Copyright 2019 Vale
# save a triangulation in vulcan format
# binary or ascii

import numpy as np
import os.path
import skimage.io

def vulcan_save_asc(nodes, faces, output):
  of = open(output, 'w')
  for i in range(3):
    print("%-24s" % "Created External", file=of)

  print("No Points: %d, No Triangles: %d" % (len(nodes), len(faces)), file=of)
  for n in nodes:
    print("Vertex: %16.4f, %16.4f, %16.4f" % tuple(n), file=of)
  for f in faces:
    print("Index : %06d, %06d, %06d" % tuple(np.add(f,(1,1,1))), file=of)



def vulcan_save_tri(nodes, faces, output):
  import vulcan
  tri = vulcan.triangulation("", "w")
  tri.set_colour(1)
  for k in nodes:
    tri.add_node(*k)
  for k in faces:
    tri.add_face(*map(int, k))
  tri.save(output)

# por each vertex, create a texture mapping node
def vulcan_texture_vt(cols, rows):
  x_grid, y_grid = np.meshgrid(np.linspace(0, 1, rows), np.linspace(1, 0, cols))
  return np.column_stack((x_grid.flat, y_grid.flat))

# save a triangulation as a Wavefront OBJ (obj, mtl, png)
def vulcan_save_obj(nodes, faces, texture, output_path, rows_cols = None):
  # obj file
  of = open(output_path, 'w')
  output_mtl = os.path.splitext(output_path)[0] + '.mtl'

  print("mtllib", output_mtl, file=of)
  print("usemtl material0", file=of)
  for n in nodes:
    print("v %f %f %f" % tuple(n), file=of)

  if rows_cols is not None:
    for uv in vulcan_texture_vt(*rows_cols):
      print("vt %f %f" % tuple(uv.tolist()), file=of)

  for f in faces:
    face1 = np.add(f,(1,1,1))
    print("f %d/%d %d/%d %d/%d" % tuple(np.column_stack((face1, face1)).flat), file=of)

  of.close()
  # tif file
  output_img = os.path.splitext(output_path)[0] + '.png'
  skimage.io.imsave(output_img, texture)

  # mtl file
  of = open(output_mtl, 'w')
  print("newmtl material0", file=of)
  print("Ka %f %f %f" % (1.0, 1.0, 1.0), file=of)
  print("Kd %f %f %f" % (1.0, 1.0, 1.0), file=of)
  print("Ks %f %f %f" % (0.0, 0.0, 0.0), file=of)
  print("map_Kd", output_img, file=of)
  of.close()

def get_boilerplate_json(output_img, output_00t):
  return {
    "properties": 
    {
     "bounding_level": 0.0,
     "highlight_col": 65535,
     "image": output_img,
     "image_col": 16777215,
     "scale": 1000.0,
     "sharp_pixels": 1,
     "triangulation": output_00t,
     "tricol": 0,
     "undercol": 16777215,
     "use_bounding": 1,
     "use_specified": 0,
     "world_col": 16777215
    }
  }

def vulcan_register_image(output_00t, texture, xyz0, xyz1, output_path):
  import json
  output_img = os.path.splitext(output_path)[0] + '.png'

  spec_json = get_boilerplate_json(output_img, output_00t)
  skimage.io.imsave(output_img, texture)
  spec_json["points"] = []
  spec_json["points"].append({"image": [0,0,0],"world": xyz0})
  spec_json["points"].append({"image": [1,1,1],"world": xyz1})

  open(output_path, 'w').write(json.dumps(spec_json, sort_keys=True, indent=4).replace(': NaN', ' = u').replace('": ', '" = '))

# save a triangulation as a Vulcan IREG (ireg, 00t, png)
def vulcan_save_ireg(nodes, faces, texture, output_path, rows_cols = None):
  import json
  spec_json = get_boilerplate_json(output_img, output_00t)

  output_00t = os.path.splitext(output_path)[0] + '.00t'
  vulcan_save_tri(nodes, faces, output_00t)
  
  output_img = os.path.splitext(output_path)[0] + '.png'
  skimage.io.imsave(output_img, texture)

  if rows_cols is not None:
    vt = vulcan_texture_vt(*rows_cols)

    spec_json["points"] = [{"image": vt[i].tolist(),"world": nodes[i].tolist()} for i in range(len(vt))]
 

  open(output_path, 'w').write(json.dumps(spec_json, sort_keys=True, indent=4).replace(': NaN', ' = u').replace('": ', '" = '))


def gdal_save_geotiff(texture, gcps, output_path):
  import gdal, osr

  driver = gdal.GetDriverByName("GTiff")
  ds = driver.Create(output_path, texture.shape[2], texture.shape[1], texture.shape[0], options = ['PHOTOMETRIC=RGB', 'PROFILE=GeoTIFF'])
  ds.SetGCPs([gdal.GCP(gcp[0][0], gcp[0][1], gcp[0][1], gcp[1][0], gcp[1][1]) for gcp in gcps], ds.GetProjection())
  for i in range(texture.shape[0]):
    ds.GetRasterBand(i+1).WriteArray(texture[i, :, :])
  ds.FlushCache()

import sys
if __name__=="__main__" and sys.argv[0].endswith('vulcan_save_tri.py'):
  import numpy as np

  texture = np.ndarray((3, 1000, 1000))
  output = "output_raw.tiff"
  gdal_save_geotiff(texture, [[[0,0,0], [0,0]], [texture.shape, texture.shape]], output)

def bm_tri_surface_color(input_tri, input_scd, input_bmf, input_var, output):
  import vulcan
  scd = VulcanScd(input_scd, 'BLOCK_COLOUR', input_var)

  bm = vulcan.block_model(input_bmf)


  n_schema = bm.model_n_schemas()-1
  tri = vulcan.triangulation(input_tri)

  voxels = Voxelschema(bm.model_schema_size(n_schema), bm.model_schema_dimensions(n_schema))

  for block in bm:
    xyzw = bm.get_multiple(['xworld', 'yworld', 'zworld'])
    xyzc = bm.get_multiple(['xcentre', 'ycentre', 'zcentre'])
    xyzl = bm.get_multiple(['xlength', 'ylength', 'zlength'])
    d = np.nan
    try:
      z = tri.get_elevation(xyzw[0], xyzw[1])
      d = abs(z - xyzw[2])
    except:
      pass

    voxels.flag_by_block(xyzc, xyzl, d, 'min')

  grid2d = voxels.get_2d_minmax('min')

  # on the texture, i is y and x is j
  texture = np.ndarray((grid2d.shape[1], grid2d.shape[0], 3))

  for i in range(voxels.shape[0]):
    for j in range(voxels.shape[1]):
      k = voxels.get_k_minmax(i, j, 'min')
      xyz = voxels.xyz([i,j,k])
      bm.find_xyz(*xyz)
      value_var = bm.get_string(input_var)
      value_rgb = scd[value_var]
      # y must be inverted to look the same way in 90o rotated models and on the image
      texture[texture.shape[0] - j - 1, i] = value_rgb

  xyz0 = bm.to_world(*voxels.xyz([0,0,0]))
  xyz1 = bm.to_world(*voxels.xyz(voxels.shape))

  if output.endswith('ireg'):
    vulcan_register_image(input_tri, texture, xyz0, xyz1, output)
  else:
    gdal_save_geotiff(texture, xyz0, xyz1, output)


main = bm_tri_surface_color

if __name__=="__main__":
  usage_gui(__doc__)
